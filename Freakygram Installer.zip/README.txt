Hi! thank you for dowloading this shitty batch and vbs Installer !
 WARNING!
if you dont press anything in 5 seconds the ¨installation¨ will not work and will need to restart the runner also sorry that i couldnt make the installer into an exe 

note: the installation will not harm your computer its just an joke vbs files , be sure to unzip it and run the installer

Hope you enjoy it

DO NOT MAKE COPIES OF THIS EXACT INSTALLER WITHOUT AN CREATORS PERMISSION